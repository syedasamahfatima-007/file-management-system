/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.app;

/**
 *
 * @author USER
 */
import javax.swing.*;  
import java.awt.*;
import java.util.ArrayList;
import java.util.Objects;

public class App {

    static String savedUsername;
    static String savedEmail;
    static String savedPassword;

    static ArrayList<UserClass> users = new ArrayList<>();

    public static final Color BG_COLOR = new Color(245, 247, 250);
    public static final Color CARD_COLOR = Color.WHITE;
    public static final Color PRIMARY_COLOR = new Color(0, 123, 255);
    public static final Color SUCCESS_COLOR = new Color(40, 167, 69);
    public static final Color INFO_COLOR = new Color(23, 162, 184);
    public static final Color DANGER_COLOR = new Color(220, 53, 69);
    public static final Color TEXT_COLOR = new Color(33, 37, 41);
    public static final Color HINT_COLOR = new Color(108, 117, 125); // ADDED
    public static final Color BORDER_COLOR = new Color(206, 212, 218); // ADDED

    public static final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 24);
    public static final Font LABEL_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font BUTTON_FONT = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font SMALL_FONT = new Font("Segoe UI", Font.PLAIN, 12);

    public static void main(String[] args) {
        setupLookAndFeel();
        SwingUtilities.invokeLater(() -> new SignUpPage().setVisible(true));
    }

    private static void setupLookAndFeel() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            UIManager.put("Label.font", LABEL_FONT);
            UIManager.put("Button.font", BUTTON_FONT);
            UIManager.put("TextField.font", LABEL_FONT);
            UIManager.put("PasswordField.font", LABEL_FONT);
            UIManager.put("TextArea.font", LABEL_FONT);
            UIManager.put("List.font", LABEL_FONT);
            UIManager.put("Panel.background", BG_COLOR);
            UIManager.put("OptionPane.background", CARD_COLOR);
            UIManager.put("OptionPane.messageForeground", TEXT_COLOR);
        } catch (Exception e) {
            System.err.println("Failed to set look and feel: " + e.getMessage());
        }
    }

    public static void showMessage(Component parent, String message, String title, int messageType) {
        JOptionPane.showMessageDialog(parent, message, title, messageType);
    }

    public static void showError(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void showSuccess(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    public static int showConfirm(Component parent, String message, String title) {
        return JOptionPane.showConfirmDialog(parent, message, title,
            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
    }

    public static void clearSession() {
        savedUsername = null;
        savedEmail = null;
        savedPassword = null;
    }
}

