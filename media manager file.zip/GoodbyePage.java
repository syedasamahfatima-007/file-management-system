/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.app;

/**
 *
 * @author USER
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GoodbyePage extends JFrame {

    private final Color BG_COLOR = new Color(245, 247, 250);
    private final Color CARD_COLOR = Color.WHITE;
    private final Color PRIMARY_COLOR = new Color(0, 123, 255);
    private final Color TEXT_COLOR = new Color(33, 37, 41);
    private final Color HINT_COLOR = new Color(108, 117, 125);
    private final Color BORDER_COLOR = new Color(206, 212, 218);

    public GoodbyePage(String userEmail) {
        setTitle("Logged Out");
        setSize(700, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG_COLOR);
        setLayout(new BorderLayout());

        Font titleFont = new Font("Segoe UI", Font.BOLD, 24);
        Font messageFont = new Font("Segoe UI", Font.PLAIN, 16);
        Font buttonFont = new Font("Segoe UI", Font.BOLD, 14);
        Font smallFont = new Font("Segoe UI", Font.PLAIN, 13);

        JPanel card = new JPanel();
        card.setBackground(CARD_COLOR);
        card.setLayout(new GridBagLayout());
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(40, 40, 40, 40)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 5, 10, 5);

        JLabel iconLabel = new JLabel("✓", SwingConstants.CENTER);
        iconLabel.setFont(new Font("Segoe UI", Font.BOLD, 48));
        iconLabel.setForeground(new Color(40, 167, 69)); // Success green
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.insets = new Insets(0, 5, 20, 5);
        card.add(iconLabel, gbc);

        JLabel title = new JLabel("Logged Out Successfully", SwingConstants.CENTER);
        title.setFont(titleFont);
        title.setForeground(TEXT_COLOR);
        gbc.gridy = 1;
        gbc.insets = new Insets(0, 5, 15, 5);
        card.add(title, gbc);

        JLabel message = new JLabel(
            "<html><center>Goodbye, <b>" + userEmail + "</b>!<br>" +
            "<span style='color: #6c757d;'>You have been logged out safely.</span></center></html>",
            SwingConstants.CENTER
        );
        message.setFont(messageFont);
        message.setForeground(TEXT_COLOR);
        gbc.gridy = 2;
        gbc.insets = new Insets(0, 5, 25, 5);
        card.add(message, gbc);

        JButton okBtn = new JButton("Back to Login");
        stylePrimaryButton(okBtn, buttonFont);
        gbc.gridy = 3;
        gbc.insets = new Insets(0, 5, 10, 5);
        card.add(okBtn, gbc);

        JLabel timerLabel = new JLabel("Redirecting in 3 seconds...", SwingConstants.CENTER);
        timerLabel.setFont(smallFont);
        timerLabel.setForeground(HINT_COLOR);
        gbc.gridy = 4;
        gbc.insets = new Insets(5, 5, 0, 5);
        card.add(timerLabel, gbc);

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(BG_COLOR);
        wrapper.add(card);
        add(wrapper, BorderLayout.CENTER);

        okBtn.addActionListener(e -> {
            this.dispose();
            new LoginPage().setVisible(true);
        });

        setVisible(true);

        final int[] seconds = {3};
        Timer timer = new Timer(1000, e -> {
            seconds[0]--;
            if (seconds[0] > 0) {
                timerLabel.setText("Redirecting in " + seconds[0] + " seconds...");
            } else {
                if (this.isVisible()) {
                    this.dispose();
                    new LoginPage().setVisible(true);
                }
                ((Timer) e.getSource()).stop();
            }
        });
        timer.start();
    }

    private void stylePrimaryButton(JButton btn, Font font) {
        btn.setFont(font);
        btn.setBackground(PRIMARY_COLOR);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(300, 42));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(new Color(0, 105, 217));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(PRIMARY_COLOR);
            }
        });
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> new GoodbyePage("test@example.com"));
    }
}
