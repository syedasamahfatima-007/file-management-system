/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.app;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
/**
 *
 * @author USER
 */
public class LoginPage extends JFrame {

    JTextField userField, emailField;
    JPasswordField passField;

    private final Color BG_COLOR = App.BG_COLOR;
    private final Color CARD_COLOR = App.CARD_COLOR;
    private final Color PRIMARY_COLOR = App.PRIMARY_COLOR;
    private final Color TEXT_COLOR = App.TEXT_COLOR;
    private final Color HINT_COLOR = new Color(108, 117, 125);

    LoginPage() {
        setTitle("Welcome Back");
        setSize(700, 700); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG_COLOR);
        setLayout(new BorderLayout());

        loadUsersFromFile();

        JPanel card = new JPanel();
        card.setBackground(CARD_COLOR);
        card.setLayout(new GridBagLayout());
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 220), 1),
            BorderFactory.createEmptyBorder(30, 40, 30, 40)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 5, 8, 5);

        Font titleFont = App.TITLE_FONT;
        Font labelFont = App.LABEL_FONT;
        Font fieldFont = App.LABEL_FONT;
        Font buttonFont = App.BUTTON_FONT;

        JLabel title = new JLabel("Login", SwingConstants.CENTER);
        title.setFont(titleFont);
        title.setForeground(TEXT_COLOR);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 5, 20, 5);
        card.add(title, gbc);

        gbc.gridwidth = 1;
        gbc.insets = new Insets(8, 5, 8, 5);

        gbc.gridy = 1; gbc.gridx = 0;
        card.add(createLabel("Username", labelFont), gbc);
        gbc.gridy = 2;
        userField = createTextField(fieldFont);
        card.add(userField, gbc);

        gbc.gridy = 3;
        card.add(createLabel("Email", labelFont), gbc);
        gbc.gridy = 4;
        emailField = createTextField(fieldFont);
        card.add(emailField, gbc);

        gbc.gridy = 5;
        card.add(createLabel("Password", labelFont), gbc);
        gbc.gridy = 6;
        passField = createPasswordField(fieldFont);
        card.add(passField, gbc);

        JButton btn = new JButton("Login");
        stylePrimaryButton(btn, buttonFont);
        gbc.gridy = 7; gbc.insets = new Insets(20, 5, 10, 5);
        card.add(btn, gbc);

        JButton backBtn = new JButton("Don't have an account? Sign Up");
        styleLinkButton(backBtn, labelFont);
        gbc.gridy = 8; gbc.insets = new Insets(5, 5, 0, 5);
        card.add(backBtn, gbc);

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(BG_COLOR);
        wrapper.add(card);
        add(wrapper, BorderLayout.CENTER);

        btn.addActionListener(e -> handleLogin());
        backBtn.addActionListener(e -> {
            dispose();
            new SignUpPage().setVisible(true);
        });

        getRootPane().setDefaultButton(btn);

        setVisible(true);
    }

    private JLabel createLabel(String text, Font font) {
        JLabel label = new JLabel(text);
        label.setFont(font);
        label.setForeground(HINT_COLOR);
        return label;
    }

    private JTextField createTextField(Font font) {
        JTextField field = new JTextField();
        field.setFont(font);
        field.setPreferredSize(new Dimension(300, 38));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(206, 212, 218), 1),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        return field;
    }

    private JPasswordField createPasswordField(Font font) {
        JPasswordField field = new JPasswordField();
        field.setFont(font);
        field.setPreferredSize(new Dimension(300, 38));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(206, 212, 218), 1),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        return field;
    }

    private void stylePrimaryButton(JButton btn, Font font) {
        btn.setFont(font);
        btn.setBackground(PRIMARY_COLOR);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(300, 42));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(new Color(0, 105, 217));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(PRIMARY_COLOR);
            }
        });
    }

    private void styleLinkButton(JButton btn, Font font) {
        btn.setFont(font);
        btn.setForeground(PRIMARY_COLOR);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void loadUsersFromFile() {
        App.users.clear();
        try (BufferedReader br = new BufferedReader(new FileReader("users.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    try {
                        UserClass user = UserClass.fromCSV(line);
                        App.users.add(user);
                    } catch (IllegalArgumentException e) {
                        System.err.println("Skipping invalid user line: " + line);
                    }
                }
            }
        } catch (IOException ex) {
            System.out.println("No users.txt found. Starting fresh.");
        }
    }

    private void handleLogin() {
        String u = userField.getText().trim();
        String em = emailField.getText().trim();
        String pw = new String(passField.getPassword()).trim();

        if (u.isEmpty() || em.isEmpty() || pw.isEmpty()) {
            App.showError(this, "Please fill all fields!");
            return;
        }

        boolean found = false;
        UserClass loggedInUser = null;

        for (UserClass user : App.users) {
            if (user.getUsername().equalsIgnoreCase(u) &&
                user.getEmail().equalsIgnoreCase(em) &&
                user.checkPassword(pw)) {
                found = true;
                loggedInUser = user;
                break;
            }
        }

        if (found && loggedInUser != null) {
          
            App.savedUsername = loggedInUser.getUsername();
            App.savedEmail = loggedInUser.getEmail();
            App.savedPassword = loggedInUser.getPassword();

            App.showSuccess(this, "Login Successful!");
            dispose();
            new WelcomePage(loggedInUser.getEmail()).setVisible(true);
        } else {
            App.showError(this, "Invalid credentials!\nPlease check username, email and password.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoginPage());
    }
}