/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.app;

/**
 *
 * @author USER
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MediaManager extends JFrame {

    private String currentUserEmail; 
    JTextField searchField;
    List<File> uploadedFiles;
    File selectedFile;
    DefaultListModel<String> listModel;
    JList<String> fileList;

    private final Color BG_COLOR = new Color(245, 247, 250);
    private final Color CARD_COLOR = Color.WHITE;
    private final Color PRIMARY_COLOR = new Color(0, 123, 255);
    private final Color DANGER_COLOR = new Color(220, 53, 69);
    private final Color SUCCESS_COLOR = new Color(40, 167, 69);
    private final Color TEXT_COLOR = new Color(33, 37, 41);
    private final Color HINT_COLOR = new Color(108, 117, 125);
    private final Color BORDER_COLOR = new Color(206, 212, 218);

    MediaManager(String userEmail) {
        this.currentUserEmail = userEmail;
        setTitle("Media Manager Dashboard");
        setSize(900, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG_COLOR);
        setLayout(new BorderLayout(0, 0));

        uploadedFiles = new ArrayList<>();

        Font titleFont = new Font("Segoe UI", Font.BOLD, 28);
        Font labelFont = new Font("Segoe UI", Font.PLAIN, 14);
        Font fieldFont = new Font("Segoe UI", Font.PLAIN, 14);
        Font buttonFont = new Font("Segoe UI", Font.BOLD, 13);
        Font listFont = new Font("Segoe UI", Font.PLAIN, 14);

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(CARD_COLOR);
        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR),
            BorderFactory.createEmptyBorder(20, 30, 20, 30)
        ));

        JLabel title = new JLabel("Media Manager");
        title.setFont(titleFont);
        title.setForeground(TEXT_COLOR);
        header.add(title, BorderLayout.CENTER);
        add(header, BorderLayout.NORTH);

        JPanel mainCard = new JPanel(new BorderLayout(0, 15));
        mainCard.setBackground(CARD_COLOR);
        mainCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(20, 30, 20, 30)
        ));

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.setBackground(CARD_COLOR);

        JPanel searchPanel = new JPanel(new GridBagLayout());
        searchPanel.setBackground(CARD_COLOR);
        searchPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, 0, 10);

        JLabel searchLabel = new JLabel("Search Files:");
        searchLabel.setFont(labelFont);
        searchLabel.setForeground(HINT_COLOR);
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        searchPanel.add(searchLabel, gbc);

        searchField = new JTextField();
        searchField.setFont(fieldFont);
        searchField.setPreferredSize(new Dimension(0, 38));
        searchField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        gbc.gridx = 1; gbc.weightx = 1.0;
        searchPanel.add(searchField, gbc);

        JButton searchBtn = new JButton("Search");
        stylePrimaryButton(searchBtn, buttonFont);
        searchBtn.setPreferredSize(new Dimension(100, 38));
        gbc.gridx = 2; gbc.weightx = 0; gbc.insets = new Insets(0, 0, 0, 0);
        searchPanel.add(searchBtn, gbc);

        topPanel.add(searchPanel);
        topPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        buttonPanel.setBackground(CARD_COLOR);
        buttonPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));

        JButton uploadBtn = new JButton("⬆ Upload File");
        styleSuccessButton(uploadBtn, buttonFont);
        buttonPanel.add(uploadBtn);

        JButton openBtn = new JButton("📂 Open File");
        stylePrimaryButton(openBtn, buttonFont);
        buttonPanel.add(openBtn);

        JButton deleteBtn = new JButton("🗑 Delete File");
        styleDangerButton(deleteBtn, buttonFont);
        buttonPanel.add(deleteBtn);

        topPanel.add(buttonPanel);
        mainCard.add(topPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout(0, 8));
        centerPanel.setBackground(CARD_COLOR);

        JLabel listLabel = new JLabel("Uploaded Files");
        listLabel.setFont(labelFont);
        listLabel.setForeground(HINT_COLOR);
        centerPanel.add(listLabel, BorderLayout.NORTH);

        listModel = new DefaultListModel<>();
        fileList = new JList<>(listModel);
        fileList.setFont(listFont);
        fileList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        fileList.setBackground(new Color(248, 249, 250));
        fileList.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        fileList.setSelectionBackground(new Color(0, 123, 255, 50));
        fileList.setSelectionForeground(TEXT_COLOR);

        JScrollPane scrollPane = new JScrollPane(fileList);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        scrollPane.getViewport().setBackground(new Color(248, 249, 250));
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        mainCard.add(centerPanel, BorderLayout.CENTER);

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(BG_COLOR);
        wrapper.setBorder(BorderFactory.createEmptyBorder(15, 30, 15, 30));
        GridBagConstraints wrapperGbc = new GridBagConstraints();
        wrapperGbc.fill = GridBagConstraints.BOTH;
        wrapperGbc.weightx = 1.0; wrapperGbc.weighty = 1.0;
        wrapper.add(mainCard, wrapperGbc);
        add(wrapper, BorderLayout.CENTER);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER));
        footer.setBackground(CARD_COLOR);
        footer.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER_COLOR),
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        ));

        JButton backBtn = new JButton("← Back to Dashboard");
        styleSecondaryButton(backBtn, buttonFont);
        backBtn.addActionListener(e -> {
        dispose();
        new WelcomePage(currentUserEmail).setVisible(true);
});
footer.add(backBtn);

        add(footer, BorderLayout.SOUTH);

        searchBtn.addActionListener(e -> handleSearch());
        searchField.addActionListener(e -> handleSearch());

        uploadBtn.addActionListener(e -> handleUpload());
        openBtn.addActionListener(e -> handleOpen());
        deleteBtn.addActionListener(e -> handleDelete());

        fileList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && fileList.getSelectedIndex() != -1 
                && fileList.getSelectedIndex() < uploadedFiles.size()) {
                selectedFile = uploadedFiles.get(fileList.getSelectedIndex());
            }
        });

        setVisible(true);
        showAllFiles();
    }

    private void stylePrimaryButton(JButton btn, Font font) {
        btn.setFont(font);
        btn.setBackground(PRIMARY_COLOR);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(140, 38));
        addHoverEffect(btn, PRIMARY_COLOR, new Color(0, 105, 217));
    }

    private void styleSuccessButton(JButton btn, Font font) {
        btn.setFont(font);
        btn.setBackground(SUCCESS_COLOR);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(140, 38));
        addHoverEffect(btn, SUCCESS_COLOR, new Color(33, 136, 56));
    }

    private void styleDangerButton(JButton btn, Font font) {
        btn.setFont(font);
        btn.setBackground(DANGER_COLOR);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(140, 38));
        addHoverEffect(btn, DANGER_COLOR, new Color(200, 35, 51));
    }

    private void styleSecondaryButton(JButton btn, Font font) {
        btn.setFont(font);
        btn.setBackground(CARD_COLOR);
        btn.setForeground(TEXT_COLOR);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(180, 38));
        addHoverEffect(btn, CARD_COLOR, new Color(248, 249, 250));
    }

    private void addHoverEffect(JButton btn, Color normal, Color hover) {
        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) { btn.setBackground(hover); }
            @Override
            public void mouseExited(MouseEvent e) { btn.setBackground(normal); }
        });
    }

    private void handleSearch() {
        String keyword = searchField.getText().trim().toLowerCase();
        listModel.clear();

        if (keyword.isEmpty()) {
            showAllFiles();
            return;
        }

        for (File file : uploadedFiles) {
            if (file.getName().toLowerCase().contains(keyword)) {
                listModel.addElement("📄 " + file.getName());
            }
        }
        if (listModel.isEmpty()) {
            listModel.addElement("No files found matching: " + keyword);
        }
    }

    private void handleUpload() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(this);

        if (result == JFileChooser.APPROVE_OPTION) {
            selectedFile = fileChooser.getSelectedFile();
            uploadedFiles.add(selectedFile);
            showAllFiles();
            JOptionPane.showMessageDialog(this, "Uploaded: " + selectedFile.getName(),
                "Success", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void handleOpen() {
        int selectedIndex = fileList.getSelectedIndex();
        if (selectedIndex == -1 || selectedIndex >= uploadedFiles.size()) {
            showError("Please select a file from the list first!");
            return;
        }

        selectedFile = uploadedFiles.get(selectedIndex);

        if (selectedFile != null && selectedFile.exists()) {
            try {
                Desktop.getDesktop().open(selectedFile);
            } catch (IOException ex) {
                showError("Cannot open file: " + ex.getMessage());
                showFileInNewWindow(selectedFile);
            }
        } else {
            showError("File doesn't exist!");
        }
    }

    private void handleDelete() {
        int selectedIndex = fileList.getSelectedIndex();
        if (selectedIndex == -1 || selectedIndex >= uploadedFiles.size()) {
            showError("Please select a file to delete!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete this file from the list?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            File fileToDelete = uploadedFiles.get(selectedIndex);
            uploadedFiles.remove(selectedIndex);
            showAllFiles();
            JOptionPane.showMessageDialog(this, "Removed: " + fileToDelete.getName(),
                "Deleted", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void showAllFiles() {
        listModel.clear();
        if (uploadedFiles.isEmpty()) {
            listModel.addElement("No files uploaded yet. Click 'Upload File' to add.");
        } else {
            for (File file : uploadedFiles) {
                listModel.addElement("📄 " + file.getName());
            }
        }
    }

    private void showFileInNewWindow(File file) {
        JFrame fileViewer = new JFrame("Viewing: " + file.getName());
        fileViewer.setSize(700, 500);
        fileViewer.setLocationRelativeTo(this);
        fileViewer.getContentPane().setBackground(BG_COLOR);

        JTextArea fileContent = new JTextArea();
        fileContent.setEditable(false);
        fileContent.setFont(new Font("Consolas", Font.PLAIN, 13));
        fileContent.setMargin(new Insets(10, 10, 10, 10));

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine())!= null) {
                fileContent.append(line + "\n");
            }
        } catch (IOException ex) {
            fileContent.setText("Cannot read file: " + ex.getMessage());
        }

        JScrollPane scroll = new JScrollPane(fileContent);
        scroll.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        fileViewer.add(scroll);
        fileViewer.setVisible(true);
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> new MediaManager("test@example.com"));
    }
}