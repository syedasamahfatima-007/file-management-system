/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.app;

/**
 *
 * @author USER
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class SignUpPage extends JFrame {

    JTextField usernameField, emailField;
    JPasswordField passwordField, confirmField;

    private final Color BG_COLOR = App.BG_COLOR;
    private final Color CARD_COLOR = App.CARD_COLOR;
    private final Color PRIMARY_COLOR = App.PRIMARY_COLOR;
    private final Color TEXT_COLOR = App.TEXT_COLOR;
    private final Color HINT_COLOR = App.HINT_COLOR;
    private final Color BORDER_COLOR = App.BORDER_COLOR;

    SignUpPage() {
        setTitle("Create Account");
        setSize(700, 700); // 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG_COLOR);
        setLayout(new BorderLayout());

        JPanel card = new JPanel();
        card.setBackground(CARD_COLOR);
        card.setLayout(new GridBagLayout());
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(30, 40, 30, 40)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 5, 8, 5);

        Font titleFont = App.TITLE_FONT;
        Font labelFont = App.LABEL_FONT;
        Font fieldFont = App.LABEL_FONT;
        Font buttonFont = App.BUTTON_FONT;

        JLabel title = new JLabel("Sign Up", SwingConstants.CENTER);
        title.setFont(titleFont);
        title.setForeground(TEXT_COLOR);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 5, 20, 5);
        card.add(title, gbc);

        gbc.gridwidth = 1;
        gbc.insets = new Insets(8, 5, 8, 5);

        gbc.gridy = 1; gbc.gridx = 0;
        card.add(createLabel("Username", labelFont), gbc);
        gbc.gridy = 2;
        usernameField = createTextField(fieldFont);
        card.add(usernameField, gbc);

        gbc.gridy = 3;
        card.add(createLabel("Email", labelFont), gbc);
        gbc.gridy = 4;
        emailField = createTextField(fieldFont);
        card.add(emailField, gbc);

        gbc.gridy = 5;
        card.add(createLabel("Password", labelFont), gbc);
        gbc.gridy = 6;
        passwordField = createPasswordField(fieldFont);
        card.add(passwordField, gbc);

        gbc.gridy = 7;
        card.add(createLabel("Confirm Password", labelFont), gbc);
        gbc.gridy = 8;
        confirmField = createPasswordField(fieldFont);
        card.add(confirmField, gbc);
        JButton btn = new JButton("Create Account");
        stylePrimaryButton(btn, buttonFont);
        gbc.gridy = 9; gbc.insets = new Insets(20, 5, 10, 5);
        card.add(btn, gbc);

        JButton loginBtn = new JButton("Already have an account? Login");
        styleLinkButton(loginBtn, labelFont);
        gbc.gridy = 10; gbc.insets = new Insets(5, 5, 0, 5);
        card.add(loginBtn, gbc);

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(BG_COLOR);
        wrapper.add(card);
        add(wrapper, BorderLayout.CENTER);

        btn.addActionListener(e -> handleSignUp());
        loginBtn.addActionListener(e -> {
            dispose();
            new LoginPage().setVisible(true);
        });

        getRootPane().setDefaultButton(btn);

        setVisible(true);
    }

    private JLabel createLabel(String text, Font font) {
        JLabel label = new JLabel(text);
        label.setFont(font);
        label.setForeground(HINT_COLOR);
        return label;
    }

    private JTextField createTextField(Font font) {
        JTextField field = new JTextField();
        field.setFont(font);
        field.setPreferredSize(new Dimension(300, 38));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        return field;
    }

    private JPasswordField createPasswordField(Font font) {
        JPasswordField field = new JPasswordField();
        field.setFont(font);
        field.setPreferredSize(new Dimension(300, 38));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER_COLOR, 1),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        return field;
    }

    private void stylePrimaryButton(JButton btn, Font font) {
        btn.setFont(font);
        btn.setBackground(PRIMARY_COLOR);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(300, 42));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(new Color(0, 105, 217));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(PRIMARY_COLOR);
            }
        });
    }

    private void styleLinkButton(JButton btn, Font font) {
        btn.setFont(font);
        btn.setForeground(PRIMARY_COLOR);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    private void handleSignUp() {
        String u = usernameField.getText().trim();
        String em = emailField.getText().trim();
        String pw = new String(passwordField.getPassword()).trim();
        String cp = new String(confirmField.getPassword()).trim();

        if (u.isEmpty() || em.isEmpty() || pw.isEmpty() || cp.isEmpty()) {
            App.showError(this, "Please fill all fields!");
            return;
        }
        if (!pw.equals(cp)) {
            App.showError(this, "Passwords do not match!");
            confirmField.setText("");
            return;
        }

        for (UserClass existingUser : App.users) {
            if (existingUser.matchesUsername(u)) {
                App.showError(this, "Username already taken!\nPlease choose a different username.");
                usernameField.requestFocus();
                return;
            }
            if (existingUser.matchesEmail(em)) {
                App.showError(this, "Email already registered!\nPlease login or use a different email.");
                emailField.requestFocus();
                return;
            }
        }

        try {
            UserClass newUser = new UserClass(u, em, pw);

            App.users.add(newUser);

            try (BufferedWriter bw = new BufferedWriter(new FileWriter("users.txt", true))) {
                bw.write(newUser.toCSV());
                bw.newLine();
            }
            App.savedUsername = newUser.getUsername();
            App.savedEmail = newUser.getEmail();
            App.savedPassword = newUser.getPassword();

            App.showSuccess(this, "Account created successfully!\nWelcome, " + newUser.getUsername() + "!");
            dispose();
            new LoginPage().setVisible(true);

        } catch (IllegalArgumentException ex) {
            App.showError(this, ex.getMessage());
        } catch (IOException ex) {
            App.showError(this, "Error saving user: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SignUpPage());
    }
}