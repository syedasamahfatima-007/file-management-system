/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.app;

/**
 *
 * @author USER
 */
import java.util.Objects;
class UserClass {
    private String username;
    private String email;
    private String password;
    private String registrationDate;

    public UserClass(String username, String email, String password) {
        setUsername(username);
        setEmail(email);
        setPassword(password);
        this.registrationDate = java.time.LocalDateTime.now().toString();
    }

    public UserClass() {
        this.registrationDate = java.time.LocalDateTime.now().toString();
    }

    public String getUsername() { return username; }
    public String getEmail() { return email; }
    public String getPassword() { return password; }
    public String getRegistrationDate() { return registrationDate; }

    public void setUsername(String username) {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username cannot be empty");
        }
        if (username.trim().length() < 3) {
            throw new IllegalArgumentException("Username must be at least 3 characters");
        }
        if (username.trim().length() > 20) {
            throw new IllegalArgumentException("Username must be less than 20 characters");
        }
        if (!username.matches("^[a-zA-Z0-9_]+$")) {
            throw new IllegalArgumentException("Username can only contain letters, numbers and underscore");
        }
        this.username = username.trim();
    }

    public void setEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            throw new IllegalArgumentException("Email cannot be empty");
        }
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        if (!email.matches(emailRegex)) {
            throw new IllegalArgumentException("Invalid email format. Example: user@example.com");
        }
        this.email = email.trim().toLowerCase();
    }

    public void setPassword(String password) {
        if (password == null || password.trim().isEmpty()) {
            throw new IllegalArgumentException("Password cannot be empty");
        }
        if (password.length() < 6) {
            throw new IllegalArgumentException("Password must be at least 6 characters");
        }
        if (password.length() > 50) {
            throw new IllegalArgumentException("Password must be less than 50 characters");
        }
        this.password = password;
    }

    public String toCSV() {
        return username + "," + email + "," + password;
    }

    public static UserClass fromCSV(String csvLine) {
        String[] data = csvLine.split(",");
        if (data.length!= 3) {
            throw new IllegalArgumentException("Invalid CSV format. Expected: username,email,password");
        }
        return new UserClass(data[0].trim(), data[1].trim(), data[2].trim());
    }

    public boolean checkPassword(String inputPassword) {
        return this.password.equals(inputPassword);
    }

    public boolean matchesUsername(String username) {
        return this.username.equalsIgnoreCase(username);
    }

    public boolean matchesEmail(String email) {
        return this.email.equalsIgnoreCase(email);
    }

    @Override
    public String toString() {
        return "User{username='" + username + "', email='" + email + "', password='****'}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass()!= o.getClass()) return false;
        UserClass userClass = (UserClass) o;
        return Objects.equals(username.toLowerCase(), userClass.username.toLowerCase()) ||
               Objects.equals(email.toLowerCase(), userClass.email.toLowerCase());
    }

    @Override
    public int hashCode() {
        return Objects.hash(username.toLowerCase(), email.toLowerCase());
    }
}